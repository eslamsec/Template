  <style>
      .slimScrollBar {
          width: 12px ! important;
          background: rgb(38 6 210) !important;
      }
  </style>
  <div class="left-side-menu">

      <div class="slimscroll-menu" id="slimscroll">
          <div id="sidebar-menu">
              <ul class="metismenu" id="side-menu">

                  <!-- <li class="menu-title mt-2">CRM</li> -->
                  <?php #page('theme/crm_menu',$option);
                  ?>


                  <li class="menu-title"><?php echo e(translate('MASTER')); ?></li>
                  <li>
                      <a  href="javascript:void(0);" title="<?php echo e(translate('Company')); ?>"  >
                          <i class="icon-briefcase"></i>
                          <span><?php echo e(translate('Company')); ?></span>
                          <span class="menu-arrow"></span>
                      </a>
                      

                  </li>
                  



                  <li>&nbsp;</li>
                  <li>&nbsp;</li>
                  <li>&nbsp;</li>
                  <li>&nbsp;</li>
              </ul>
          </div>
          <div class="clearfix"></div>
      </div>
  </div>
  <script type="text/javascript">
      function ChangeApprovalLink(link) {
          if (link == 'Voucher') {
              $('.Voucher-un').show();
              $('.Ledger-un').hide();
          } else {
              $('.Voucher-un').hide();
              $('.Ledger-un').show();
          }
      }
      $(document).ready(function() {
          if ($('#approval-process-select').length) {
              setTimeout(() => $('#approval-process-select').trigger('change'), 1000);
          }
      })
  </script>
<?php /**PATH C:\xampp\htdocs\hotel-management_t\resources\views/theme/menu.blade.php ENDPATH**/ ?>