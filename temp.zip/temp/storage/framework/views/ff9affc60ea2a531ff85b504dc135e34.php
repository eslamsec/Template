     <?php if($room_types->count()): ?>
         <table class="table table-bordered" id="room_types_table" data-route="<?php echo e(route('room_type.table')); ?>">
             <thead>
                 <tr>
                     <th style="width:60px"><?php echo e(translate('SL No')); ?></th> 
                     <th><?php echo e(translate('Name')); ?></th>
                     <th style="width:100px"></th>
                 </tr>
             </thead>
             <tbody>
                 <?php $__currentLoopData = $room_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room_type_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                         <?php if(method_exists($room_types, 'currentPage')): ?>
                             <td><?php echo e(($room_types->currentPage() - 1) * $room_types->perPage() + $loop->iteration); ?></td>
                         <?php else: ?>
                             <td><?php echo e($loop->iteration); ?></td>
                         <?php endif; ?> 
                         <td><?php echo e($room_type_item->name); ?></td>
                         <td class="right">
                             <div class="dropdown notification-list dropdown">
                                 <a class="btaction" data-toggle="dropdown" href="#" role="button"
                                     aria-haspopup="false" aria-expanded="false">Action <i
                                         class="icon-arrow-down-circle"></i></a>
                                 <div class="dropdown-menu dropdown-menu-right profile-dropdown">
                                     <a href="#" class="dropdown-item notify-item" data-module="room_types"
                                         data-id="<?php echo e($room_type_item->id); ?>"
                                         data-route-store="<?php echo e(route('room_type.store')); ?>"
                                         data-route-form="<?php echo e(route('room_type.form')); ?>"
                                         data-route-edit="<?php echo e(route('room_type.edit', ':id')); ?>"
                                         data-route-update="<?php echo e(route('room_type.update', ':id')); ?>"
                                         onclick="form_modal(this)"><?php echo e(translate('Edit')); ?></a>
                                     <a href="#" class="dropdown-item notify-item" data-module="room_types"
                                         data-id="<?php echo e($room_type_item->id); ?>"
                                         data-route="<?php echo e(route('room_type.delete', ':id')); ?>"
                                         onclick="erp_delete(this)"><?php echo e(translate('Delete')); ?></a>
                                 </div>
                             </div>
                         </td>
                     </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>

         <?php if(method_exists($room_types, 'links')): ?>
             <div class="pagination-wrapper">
                 <?php echo e($room_types->appends(['wrapper' => 'room_types_table_wrapper'])->links()); ?>

             </div>
         <?php endif; ?>
     <?php else: ?> 
         <div class="col-md-12 col-md-12-padding">
             <div class="box ">
                 <div class="box-body">

                     <div class="intro text-center">
                         <div class="videoimg"> </div>
                         <h3><?php echo e(translate('Empty List')); ?></h3>
                         <p class="text-muted"><?php echo e(translate('No Data Found')); ?></p>

                     </div>
                 </div>

                 <div class="box-footer clearfix">

                 </div>
             </div>
         </div>


     <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_master/room_type/table.blade.php ENDPATH**/ ?>