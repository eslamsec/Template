     <?php if($room_sizes->count()): ?>
         <table class="table table-bordered" id="room_sizes_table" data-route="<?php echo e(route('room_size.table')); ?>">
             <thead>
                 <tr>
                     <th style="width:60px"><?php echo e(translate('SL No')); ?></th> 
                     <th><?php echo e(translate('Name')); ?></th>
                     <th style="width:100px"></th>
                 </tr>
             </thead>
             <tbody>
                 <?php $__currentLoopData = $room_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room_size_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                         <?php if(method_exists($room_sizes, 'currentPage')): ?>
                             <td><?php echo e(($room_sizes->currentPage() - 1) * $room_sizes->perPage() + $loop->iteration); ?></td>
                         <?php else: ?>
                             <td><?php echo e($loop->iteration); ?></td>
                         <?php endif; ?> 
                         <td><?php echo e($room_size_item->name); ?></td>
                         <td class="right">
                             <div class="dropdown notification-list dropdown">
                                 <a class="btaction" data-toggle="dropdown" href="#" role="button"
                                     aria-haspopup="false" aria-expanded="false">Action <i
                                         class="icon-arrow-down-circle"></i></a>
                                 <div class="dropdown-menu dropdown-menu-right profile-dropdown">
                                     <a href="#" class="dropdown-item notify-item" data-module="room_sizes"
                                         data-id="<?php echo e($room_size_item->id); ?>"
                                         data-route-store="<?php echo e(route('room_size.store')); ?>"
                                         data-route-form="<?php echo e(route('room_size.form')); ?>"
                                         data-route-edit="<?php echo e(route('room_size.edit', ':id')); ?>"
                                         data-route-update="<?php echo e(route('room_size.update', ':id')); ?>"
                                         onclick="form_modal(this)"><?php echo e(translate('Edit')); ?></a>
                                     <a href="#" class="dropdown-item notify-item" data-module="room_sizes"
                                         data-id="<?php echo e($room_size_item->id); ?>"
                                         data-route="<?php echo e(route('room_size.delete', ':id')); ?>"
                                         onclick="erp_delete(this)"><?php echo e(translate('Delete')); ?></a>
                                 </div>
                             </div>
                         </td>
                     </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>

         <?php if(method_exists($room_sizes, 'links')): ?>
             <div class="pagination-wrapper">
                 <?php echo e($room_sizes->appends(['wrapper' => 'room_sizes_table_wrapper'])->links()); ?>

             </div>
         <?php endif; ?>
     <?php else: ?> 
         <div class="col-md-12 col-md-12-padding">
             <div class="box ">
                 <div class="box-body">

                     <div class="intro text-center">
                         <div class="videoimg"> </div>
                         <h3><?php echo e(translate('Empty List')); ?></h3>
                         <p class="text-muted"><?php echo e(translate('No Data Found')); ?></p>

                     </div>
                 </div>

                 <div class="box-footer clearfix">

                 </div>
             </div>
         </div>


     <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_facility/room_size/table.blade.php ENDPATH**/ ?>