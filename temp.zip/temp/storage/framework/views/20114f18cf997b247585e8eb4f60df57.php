<div class="form-group">
    <label><?php echo e(translate('Floor Name')); ?></label>
    <input type="text" class="form-control" name="name">
</div>
<div class="form-group">
    <label><?php echo e(translate('Building Name')); ?></label>
    <select name="building_id" class="form-control">
        <option value=""><?php echo e(translate('Select Building')); ?></option>
        <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($building->id); ?>"><?php echo e($building->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
</div>

<div class="form-group">
    <label><?php echo e(translate('Building Code')); ?></label>
    <input type="text" class="form-control" name="code">
</div>
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_management/floor/form.blade.php ENDPATH**/ ?>