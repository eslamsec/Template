<div class="form-group">
    <label><?php echo e(translate('Room Size Name')); ?></label>
    <input type="text" class="form-control" name="name">
</div>
 
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_facility/room_size/form.blade.php ENDPATH**/ ?>