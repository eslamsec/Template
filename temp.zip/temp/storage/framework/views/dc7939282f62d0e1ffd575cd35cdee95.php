<div class="row">
    <div class="col-6">
        <div class="form-group">
            <label><?php echo e(translate('Name')); ?></label>
            <input type="text" class="form-control" name="name">
        </div>
    </div>

    <div class="col-6"> 
        <div class="form-group">
            <label><?php echo e(translate('Building')); ?></label>
            <select name="building_ids[]" id="building_ids" class="form-control selectize  filterproduct mlt"
                multiple="multiple">
               <?php $__currentLoopData = $buildings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $building): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($building->id); ?>"><?php echo e($building->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>
    <div class="col-6">
        <div class="form-group">
            <label><?php echo e(translate('Code')); ?></label>
            <input type="text" class="form-control" name="code">
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function() {
		$('.mlt').multiselect({ 
			enableFiltering: true,
			numberDisplayed: 1,
			enableCaseInsensitiveFiltering: true,
			maxHeight:250,
             buttonWidth: '100%',
			onChange: function(option) {
				
			}
		});
		$('.mlt').hide();
     });
</script><?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_management/floor/search.blade.php ENDPATH**/ ?>