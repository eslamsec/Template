<div class="form-group">
    <label><?php echo e(translate('Bed Name')); ?></label>
    <input type="text" class="form-control" name="name">
</div>
 
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_master/bed/form.blade.php ENDPATH**/ ?>