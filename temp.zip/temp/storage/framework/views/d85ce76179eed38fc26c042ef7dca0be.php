<!DOCTYPE html>
<html lang="en" id="pages">

<head>
    <meta charset="utf-8" />
    <title><?php echo $__env->yieldContent('title', translate('hotel_management')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="ERP" name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <link rel="icon" href="<?php echo e(asset(main_path() . 'images/faviconn.png')); ?>" sizes="32x32" />
    <link href="<?php echo e(asset(main_path() . 'css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css"
        id="bootstrap-stylesheet" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link href="<?php echo e(asset(main_path() . 'css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset(main_path() . 'css/select2.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset(main_path() . 'css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-stylesheet" />
    <link href="<?php echo e(asset(main_path() . 'css/style.css')); ?>?time=<?= time() ?>" rel="stylesheet" type="text/css" />
    <link id="bsdp-css" href="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/css/bootstrap-datepicker3.min.css"
        rel="stylesheet">
    <script type="text/javascript" src="<?php echo e(asset(main_path() . 'js/jquery-3.1.1.min.js')); ?>"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset(main_path() . 'js/js/js.js')); ?>?time=<?= time() ?>"></script>
    <script src="<?php echo e(asset(main_path() . 'js/vendor.min.js')); ?>"></script>
    <script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
    <script src="https://unpkg.com/bootstrap-datepicker@1.9.0/dist/js/bootstrap-datepicker.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.1/css/selectize.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.1/js/standalone/selectize.js"></script>
    <link rel="stylesheet" href="<?php echo e(asset(main_path() . 'css/bootstrap-multiselect.css')); ?>" />
    <script src="<?php echo e(asset(main_path() . 'js/bootstrap-multiselect.js')); ?>"></script>
    <script type="text/javascript"
        src="https://cdn.tiny.cloud/1/sivmoj1u561le7ov0eiguwz73su8taudpdxipk1yyrnklgqn/tinymce/5-stable/tinymce.min.js">
    </script>
    <script type="text/javascript" src="<?php echo e(asset(main_path() . 'js/js/JSPrintManager.js')); ?>"></script>
    <script src="<?php echo e(asset(main_path() . 'lib/dropzone/dropzone.min.js')); ?>"></script>
    <link href="<?php echo e(asset(main_path() . 'lib/dropzone/dropzone.min.css')); ?>" type="text/css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/decimal.js/10.4.3/decimal.min.js"></script>
    <style>
        .loader {
            border: 16px solid #f3f3f3;
            border-radius: 50%;
            border-top: 16px solid #3498db;
            width: 60px;
            height: 60px;
            -webkit-animation: spin 2s linear infinite;
            /* Safari */
            animation: spin 2s linear infinite;
            display: none;
        }


        /* Safari */
        @-webkit-keyframes spin {
            0% {
                -webkit-transform: rotate(0deg);
            }

            100% {
                -webkit-transform: rotate(360deg);
            }
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>


    <?php echo $__env->make('theme.msg', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('theme.confirm', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('theme.modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('theme.search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div id="wrapper">
        <?php echo $__env->make('theme.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('theme.menu', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="content-page" id="pagediv">

            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('theme.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
    <div class="rightbar-overlay"></div>

    <div id="pageLoader" style="display:none">
        <div
            style="width:100%; height:100%; background:#ece3e366; position:fixed; top:0; left:0; z-index:99999999; display:flex;justify-content:center; align-items:center;">
            <i style="transform: translate(-50%, -50%);" class="fa fa-spinner fa-3x fa-pulse"></i>
        </div>
    </div>

    <script src="<?php echo e(asset(main_path() . 'js/morris.min.js')); ?>"></script>
    <script src="<?php echo e(asset(main_path() . 'js/dashboard.init.js')); ?>"></script>

    <script src="<?php echo e(asset(main_path() . 'js/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset(main_path() . 'js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset(main_path() . 'js/select2.min.js')); ?>"></script>
 
     <script src="<?php echo e(asset(main_path() . 'js/master.js')); ?>?time=<?= time() ?>"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/theme/main.blade.php ENDPATH**/ ?>