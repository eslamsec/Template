

<?php $__env->startSection('title', translate('Floor List')); ?>
<?php $__env->startSection('css'); ?>
    <script type="text/javascript" src="<?php echo e(asset(main_path() . 'js/bootstrap-multiselect.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset(main_path() . 'css/bootstrap-multiselect.css')); ?>" type="text/css" />
    <script src="<?php echo e(asset(main_path() . 'js/bootstrap3-typeahead.js')); ?>"></script>
    <script src="<?php echo e(asset(main_path() . 'asset/room-reservation/js.js')); ?>"></script>
    <link href="<?php echo e(asset(main_path() . 'asset/room-reservation/style.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <div class="content">
        <div class="container-fluid">

            <div class="page-title-box">
                <div class="row">
                    <div class="col-md-3">
                        <h4 class="page-title ml-2"><?php echo e(translate('Floors')); ?></h4>
                    </div>

                    <div class="col-md-9">
                        <div class="page-title-right">
                            <div class="titlemenu">
                                <a class="btn btn-primary" data-module="floors" data-table="#floors_table"
                                    onclick="form_modal(this)" data-fields='["name","code"]'
                                    data-route-store="<?php echo e(route('floor.store')); ?>"
                                    data-route-form="<?php echo e(route('floor.form')); ?>"
                                    data-route-edit="<?php echo e(route('floor.edit', ':id')); ?>"
                                    data-route-update="<?php echo e(route('floor.update', ':id')); ?>"><i class="icon-plus"></i>
                                    <?php echo e(translate('Add New')); ?></a>
                                <a class="btn btn-primary show_all_btn" data-val="1" onclick="list_all(this)">
                                    <i class="fa fa-list"></i> <?php echo e(translate('Show All')); ?>

                                </a>
                                <a href="#" class="btn btn-primary" data-url="<?php echo e(route('floor.search_form')); ?>"
                                    data-title="Search" data-modalwidth="50" onclick="return search_form(this)"
                                    data-route="<?php echo e(route('floor.search_results')); ?>">
                                    <i class="ti-search"></i><?php echo e(translate('Search')); ?>

                                </a>
                                <a href="#" class="btn btn-primary clearsearch d-none"
                                    style=" background-color: #ff5d48; border-color: #ff5d48;"
                                    data-url="<?php echo e(route('floor.table')); ?>" onclick="return clear_search(this)">
                                    <i class="icon-plus"></i> <?php echo e(translate('Clear Search')); ?>

                                </a>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 col-xl-12">
                    <div class="card-box ajax-wrapper" id="floors_table_wrapper" data-wrapper="floors_table_wrapper">
                        <?php echo $__env->make('room_management.floor.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
   



<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_management/floor/list.blade.php ENDPATH**/ ?>