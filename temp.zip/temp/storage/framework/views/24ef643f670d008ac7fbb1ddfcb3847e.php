<div class="row">
    <div class="col-6"> 
        <div class="form-group">
            <label><?php echo e(translate('Building Name')); ?></label>
            <input type="text" class="form-control" name="name">
        </div>
    </div>
    <div class="col-6"> 
        <div class="form-group">
            <label><?php echo e(translate('Building Code')); ?></label>
            <input type="text" class="form-control" name="code">
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_management/building/search.blade.php ENDPATH**/ ?>