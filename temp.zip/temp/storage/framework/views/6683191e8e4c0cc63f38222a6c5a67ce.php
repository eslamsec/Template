<div class="form-group">
    <label><?php echo e(translate('Room Facility Name')); ?></label>
    <input type="text" class="form-control" name="name">
</div>
 
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_facility/room_facility/form.blade.php ENDPATH**/ ?>