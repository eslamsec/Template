<div class="form-group">
    <label><?php echo e(translate('Room Type Name')); ?></label>
    <input type="text" class="form-control" name="name">
</div>
 
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_master/room_type/form.blade.php ENDPATH**/ ?>