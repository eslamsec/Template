     <?php if($room_facilities->count()): ?>
         <table class="table table-bordered" id="room_facilities_table" data-route="<?php echo e(route('room_facility.table')); ?>">
             <thead>
                 <tr>
                     <th style="width:60px"><?php echo e(translate('SL No')); ?></th> 
                     <th><?php echo e(translate('Name')); ?></th>
                     <th style="width:100px"></th>
                 </tr>
             </thead>
             <tbody>
                 <?php $__currentLoopData = $room_facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room_facility_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                         <?php if(method_exists($room_facilities, 'currentPage')): ?>
                             <td><?php echo e(($room_facilities->currentPage() - 1) * $room_facilities->perPage() + $loop->iteration); ?></td>
                         <?php else: ?>
                             <td><?php echo e($loop->iteration); ?></td>
                         <?php endif; ?> 
                         <td><?php echo e($room_facility_item->name); ?></td>
                         <td class="right">
                             <div class="dropdown notification-list dropdown">
                                 <a class="btaction" data-toggle="dropdown" href="#" role="button"
                                     aria-haspopup="false" aria-expanded="false">Action <i
                                         class="icon-arrow-down-circle"></i></a>
                                 <div class="dropdown-menu dropdown-menu-right profile-dropdown">
                                     <a href="#" class="dropdown-item notify-item" data-module="room_facilities"
                                         data-id="<?php echo e($room_facility_item->id); ?>"
                                         data-route-store="<?php echo e(route('room_facility.store')); ?>"
                                         data-route-form="<?php echo e(route('room_facility.form')); ?>"
                                         data-route-edit="<?php echo e(route('room_facility.edit', ':id')); ?>"
                                         data-route-update="<?php echo e(route('room_facility.update', ':id')); ?>"
                                         onclick="form_modal(this)"><?php echo e(translate('Edit')); ?></a>
                                     <a href="#" class="dropdown-item notify-item" data-module="room_facilities"
                                         data-id="<?php echo e($room_facility_item->id); ?>"
                                         data-route="<?php echo e(route('room_facility.delete', ':id')); ?>"
                                         onclick="erp_delete(this)"><?php echo e(translate('Delete')); ?></a>
                                 </div>
                             </div>
                         </td>
                     </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </tbody>
         </table>

         <?php if(method_exists($room_facilities, 'links')): ?>
             <div class="pagination-wrapper">
                 <?php echo e($room_facilities->appends(['wrapper' => 'room_facilities_table_wrapper'])->links()); ?>

             </div>
         <?php endif; ?>
     <?php else: ?> 
         <div class="col-md-12 col-md-12-padding">
             <div class="box ">
                 <div class="box-body">

                     <div class="intro text-center">
                         <div class="videoimg"> </div>
                         <h3><?php echo e(translate('Empty List')); ?></h3>
                         <p class="text-muted"><?php echo e(translate('No Data Found')); ?></p>

                     </div>
                 </div>

                 <div class="box-footer clearfix">

                 </div>
             </div>
         </div>


     <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/room_facility/room_facility/table.blade.php ENDPATH**/ ?>