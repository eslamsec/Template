  <style>
      .slimScrollBar {
          width: 12px ! important;
          background: rgb(38 6 210) !important;
      }
  </style>
  <div class="left-side-menu">

      <div class="slimscroll-menu" id="slimscroll">
          <div id="sidebar-menu">
              <ul class="metismenu" id="side-menu">

                  <!-- <li class="menu-title mt-2">CRM</li> -->
                  <?php #page('theme/crm_menu',$option);
                  ?>


                  <li class="menu-title"><?php echo e(translate('MASTER')); ?></li>
                  <li>
                      <a  href="javascript:void(0);" title="<?php echo e(translate('Room Master')); ?>"  >
                          <i class="icon-briefcase"></i>
                          <span><?php echo e(translate('Room Master')); ?></span>
                          <span class="menu-arrow"></span>
                      </a>
                      <ul class="nav-second-level" aria-expanded="false">
                          <li>
                              <a href="<?php echo e(route('bed.list')); ?>" class="nav_link"> 
                                  <?php echo e(translate('Bed')); ?>

                              </a>
                          </li>
                          <li>
                              <a href="<?php echo e(route('booking_type.list')); ?>" class="nav_link"> 
                                  <?php echo e(translate('Booking Type')); ?>

                              </a>
                          </li>
                          
                          <li>
                              <a href="<?php echo e(route('room_type.list')); ?>" class="nav_link"> 
                                  <?php echo e(translate('Room Type')); ?>

                              </a>
                          </li>
                          
                      </ul>

                  </li>
                  <li>
                      <a  href="javascript:void(0);" title="<?php echo e(translate('Room Facility')); ?>"  >
                          <i class="icon-briefcase"></i>
                          <span><?php echo e(translate('Room Facility')); ?></span>
                          <span class="menu-arrow"></span>
                      </a>
                      <ul class="nav-second-level" aria-expanded="false"> 
                          <li>
                              <a href="<?php echo e(route('room_facility.list')); ?>" class="nav_link"> 
                                  <?php echo e(translate('Facility')); ?>

                              </a>
                          </li> 
                          
                            <li>
                                <a href="<?php echo e(route('room_size.list')); ?>" class="nav_link"> 
                                    <?php echo e(translate('Room Size')); ?>

                                </a>
                            </li> 
                            
                      </ul>

                  </li>
                  <li>
                      <a  href="javascript:void(0);" title="<?php echo e(translate('Room Management')); ?>"  >
                          <i class="icon-briefcase"></i>
                          <span><?php echo e(translate('Room Management')); ?></span>
                          <span class="menu-arrow"></span>
                      </a>
                      <ul class="nav-second-level" aria-expanded="false">
                          <li>
                              <a href="<?php echo e(route('building.list')); ?>" class="nav_link"> 
                                  <?php echo e(translate('Building')); ?>

                              </a>
                          </li>
                          <li>
                              <a href="<?php echo e(route('floor.list')); ?>" class="nav_link"> 
                                  <?php echo e(translate('Floor')); ?>

                              </a>
                          </li>
                      </ul>

                  </li>



                  <li>&nbsp;</li>
                  <li>&nbsp;</li>
                  <li>&nbsp;</li>
                  <li>&nbsp;</li>
              </ul>
          </div>
          <div class="clearfix"></div>
      </div>
  </div>
  <script type="text/javascript">
      function ChangeApprovalLink(link) {
          if (link == 'Voucher') {
              $('.Voucher-un').show();
              $('.Ledger-un').hide();
          } else {
              $('.Voucher-un').hide();
              $('.Ledger-un').show();
          }
      }
      $(document).ready(function() {
          if ($('#approval-process-select').length) {
              setTimeout(() => $('#approval-process-select').trigger('change'), 1000);
          }
      })
  </script>
<?php /**PATH C:\xampp\htdocs\hotel-management\resources\views/theme/menu.blade.php ENDPATH**/ ?>