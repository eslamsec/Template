<footer class="footer">
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 text-right">
				Powered by <a href="https://www.finexerp.com" target="_blank">FinexERP</a>
			</div>
		</div>
	</div>
</footer>
<script>
$(document).ready(function() {
   $(".slimScrollBar").css("background", "rgb(47 123 188)");
   $(".slimScrollBar").css("display", "inherit");
   //
});
</script>
                
                
  
 