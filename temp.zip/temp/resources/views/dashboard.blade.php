@extends('theme.main')

@section('title' , translate('Dashboard'))

@section('content')


@endsection